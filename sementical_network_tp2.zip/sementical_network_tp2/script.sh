

docker build -t tp2-project .


docker run --rm tp2-project
